This zip folder contains all the network diagrams used in the bibliometric analysis of the study "Modified Rice Bran Arabinoxylans by Lentinus Edodes Mycelial Enzyme as a Nutraceutical in Health and Disease – A Scoping Review with Bibliometric Analysis".

To view, download and extract all the zip files then open the Home.html with a web browser supporting the Wide Web Consortium (W3C) HTML5 standard.
